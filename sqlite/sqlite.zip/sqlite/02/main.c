/*
* filename : main.c
* path: ./
* author: liehu1119
* date : 2013-04-06
* version : 1.0
* note : main function 
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h> 
#include "sqlite3.h"

#define FILEPATH_MAX (80)

int main()
{
    /*db name start*/
    char *pPath = NULL;
    struct sqlite3 *pdb = NULL;
    char *pErrMsg = NULL;
    char dbName[] = "/mysqlite";
    pPath = (char *) malloc (FILEPATH_MAX + 10);
    if (NULL == pPath)
    {
        return -1;
    }
    memset(pPath, 0, FILEPATH_MAX + 10);
    if (NULL == getcwd(pPath, FILEPATH_MAX))
	{
		return -1;
	}
    printf("%s %d\n",pPath,strlen(pPath));
    memcpy(pPath + strlen(pPath), dbName, strlen(dbName));
    printf("%s %d\n",pPath,strlen(pPath));
    /*db name end*/

    //open or create db
    int iResult = sqlite3_open((const char *)pPath,&pdb);
    if(SQLITE_OK != iResult || NULL == pdb)
    {
      printf("invoke sqlite3_open function error!\n");
      free(pPath);
      pPath = NULL;
      return -1;
    }
	//create table
    char sqlCreateTable[] = "create table test (id integer primary key,"
                             " name text not null)";
    iResult = sqlite3_exec(pdb, sqlCreateTable, 0, 0, &pErrMsg);
    if(SQLITE_OK != iResult)
    {
      printf("%s\n", pErrMsg);
      sqlite3_free(pErrMsg);
    }
    
    sqlite3_free(pErrMsg);
	//insert table
    char sqlInsert[] = "insert into test (name) values ('aaa')";
    iResult = sqlite3_exec(pdb, sqlInsert, 0, 0, &pErrMsg);
    if(SQLITE_OK != iResult)
    {
      printf("%s\n", pErrMsg);
      sqlite3_free(pErrMsg);
    }
    sqlite3_free(pErrMsg);
	//select table
    char sqlSelect[] = "select * from test";
    char** ppTable = NULL;
    int iRow = 0;
    int iColumn = 0;
    iResult = sqlite3_get_table(pdb, sqlSelect, &ppTable, &iRow, &iColumn,&pErrMsg);
	
    if (SQLITE_OK != iResult)
    {
        printf("%s\n", pErrMsg);
    }
    sqlite3_free(pErrMsg);
    printf("select sql row %d column %d\n", iRow, iColumn);
    if (NULL != ppTable)
    {
        int i = 1;
        for (; i <= iRow; i++)
        {
            int j = 0;
            for (; j < iColumn; j++)
            {
                if (NULL != ppTable[i * iColumn + j])
                {
                    printf("%s    ",ppTable[i * iColumn + j]);
                }
                
            }
            printf("\n");
        }
    }
	sqlite3_free_table(ppTable);
    //close db
    iResult = sqlite3_close(pdb);
    
    if(SQLITE_OK != iResult)
    {
      return -1;
    }

    //free memory
    free(pPath);
    pPath = NULL;
    pdb = NULL;
    return 0;
}


/*
------------------------------------------------------------------------
yyyy-mm-dd		name		description
------------------------------------------------------------------------
2013-04-06		liuhuizhe	        init
------------------------------------------------------------------------
*/


