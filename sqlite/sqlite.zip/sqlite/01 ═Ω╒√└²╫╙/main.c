/*
* filename : main.c
* path: ./
* author: liehu1119
* date : 2013-04-06
* version : 1.0
* note : main function 
*/

#include "common.h"
#include "sqliteinterface.h"

#define FILEPATH_MAX (80)

int main()
{
    /*db name start*/
    char *pPath = NULL;
    char dbName[] = "/mysqlite";
    pPath = (char *) malloc (FILEPATH_MAX + 10);
    if (NULL == pPath)
    {
        return -1;
    }
    memset(pPath, 0, FILEPATH_MAX + 10);
    getcwd(pPath, FILEPATH_MAX);
    printf("%s %d\n",pPath,strlen(pPath));
    memcpy(pPath + strlen(pPath), dbName, strlen(dbName));
    printf("%s %d\n",pPath,strlen(pPath));
    /*db name end*/
    //init db
    if (DB_ERROR_OK != InitConnection())
    {
        printf("invoke InitConnection function error!\n");
        return -1;
    }
    //open or create db
    if (DB_ERROR_OK != OpenConnection(pPath))
    {
        printf("invoke OpenConnection function error!\n");
        return -1;
    }
    //check global db handle
    if (NULL == g_db)
    {
        printf("create/open database error!\n");
        return -1;
    }
    //create table
     char sqlCreateTable[] = "create table test (id integer primary key,"
                             " name text not null)";
    if (DB_ERROR_OK != ExecSQL(sqlCreateTable))
    {
        printf("create table sql error\n");
    }
    //insert
    char sqlInsert[] = "insert into test (name) values ('aaa')";
    if (DB_ERROR_OK != ExecSQL(sqlInsert))
    {
        printf("insert sql error\n");
    }
    //select 
    char sqlSelect[] = "select * from test";
    char** ppTable = NULL;
    char* pErrMsg = NULL;
    int iRow = 0;
    int iColumn = 0;
    if (DB_ERROR_OK != GetTable(sqlSelect, &ppTable, &iRow, &iColumn))
    {
        printf("select sql error\n");
    }
    printf("select sql row %d column %d\n", iRow, iColumn);
    if (NULL != ppTable)
    {
        int i = 0;
        for (; i < iRow; i++)
        {
            int j = 0;
            for (; j < iColumn; j++)
            {
                if (NULL != ppTable[i * iColumn + j])
                {
                    printf("%s    ",ppTable[i * iColumn + j]);
                }
                
            }
            printf("\n");
        }
    }
    ReleaseTableResult(ppTable);
    //close db
    if (DB_ERROR_OK != CloseConnection(g_db))
    {
        printf("invoke CloseConnection function error!\n");
        return -1;
    }

    //free memory
    free(pPath);
    pPath = NULL;
    return 0;
}


/*
------------------------------------------------------------------------
yyyy-mm-dd		name		description
------------------------------------------------------------------------
2013-04-06		liuhuizhe	        init
------------------------------------------------------------------------
*/


