/*
* filename : common.h
* path: ./
* author: liehu1119
* date : 2013-04-06
* version : 1.0
* note : common header
*/
#ifndef _COMMON_HEADER_
#define _COMMON_HEADER_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h> 

#endif //_COMMON_HEADER_
/*
------------------------------------------------------------------------
yyyy-mm-dd		name		description
------------------------------------------------------------------------
2013-04-06		liuhuizhe	        init
------------------------------------------------------------------------
*/


